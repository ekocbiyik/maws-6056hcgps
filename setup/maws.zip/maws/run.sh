#!/bin/bash
java -jar maws-6056hcgps.jar
